#!/bin/bash

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

info() { echo -e "${GREEN}[INFO]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; }

if [[ $EUID -ne 0 ]]; then
    error "Скрипт должен выполняться с правами root (администратора)."
    exit 1
fi

DEFAULT_IFACE=$(ip -o link show | awk -F': ' '{print $2}' | grep -v lo | head -n1)
if [[ -z "$DEFAULT_IFACE" ]]; then
    error "Не найдено ни одного сетевого интерфейса (кроме lo)."
    exit 1
fi

read -p "Введите имя сетевого интерфейса [по умолчанию: $DEFAULT_IFACE]: " IFACE
IFACE=${IFACE:-$DEFAULT_IFACE}

if ! ip link show "$IFACE" > /dev/null 2>&1; then
    error "Интерфейс $IFACE не существует."
    exit 1
fi

info "Выбран интерфейс: $IFACE"

show_hardware_info() {
    echo "====== Информация о сетевой карте ======"
    if command -v ethtool &> /dev/null; then
        DRIVER=$(ethtool -i "$IFACE" 2>/dev/null | grep "driver:" | awk '{print $2}')
        if [[ -n "$DRIVER" ]]; then
            echo "Модель (драйвер): $DRIVER"
        else
            echo "Модель: не удалось определить"
        fi
    else
        echo "Модель: установите ethtool для детальной информации"
    fi
    
    MAC=$(ip link show "$IFACE" | grep "link/ether" | awk '{print $2}')
    echo "MAC-адрес: $MAC"
    
    if command -v ethtool &> /dev/null; then
        ETHTOOL_OUT=$(ethtool "$IFACE" 2>/dev/null)
        SPEED=$(echo "$ETHTOOL_OUT" | grep "Speed:" | awk '{print $2}')
        DUPLEX=$(echo "$ETHTOOL_OUT" | grep "Duplex:" | awk '{print $2}')
        LINK=$(echo "$ETHTOOL_OUT" | grep "Link detected:" | awk '{print $3}')
        echo "Канальная скорость: ${SPEED:-неизвестно}"
        echo "Режим работы: ${DUPLEX:-неизвестно}"
        echo "Физическое подключение (линк): ${LINK:-неизвестно}"
    else
        warn "ethtool не установлен, невозможно получить скорость, дуплекс и линк"
    fi
    echo ""
}

show_ipv4_info() {
    echo "====== Текущая конфигурация IPv4 ======"
    # IP и маска
    IP_INFO=$(ip -4 addr show "$IFACE" | grep -oP '(?<=inet\s)\d+(\.\d+){3}/\d+')
    if [[ -n "$IP_INFO" ]]; then
        echo "IP-адрес/маска: $IP_INFO"
    else
        echo "IP-адрес/маска: не назначен"
    fi
    
    GATEWAY=$(ip route show default | grep -oP '(?<=via\s)\d+(\.\d+){3}')
    echo "Шлюз по умолчанию: ${GATEWAY:-не задан}"
    
    if [[ -f /etc/resolv.conf ]]; then
        DNS=$(grep "^nameserver" /etc/resolv.conf | awk '{print $2}' | tr '\n' ' ')
        echo "DNS-серверы: ${DNS:-не заданы}"
    else
        echo "DNS-серверы: файл /etc/resolv.conf отсутствует"
    fi
    echo ""
}

set_static() {
    info "Настройка статического IP (сценарий #1)..."
    
    if pgrep dhclient > /dev/null; then
        pkill dhclient || true
        info "DHCP-клиент остановлен"
    fi
    
    ip addr flush dev "$IFACE" 2>/dev/null
    ip route flush dev "$IFACE" 2>/dev/null
    
    ip addr add 10.100.0.2/24 dev "$IFACE"
    info "IP-адрес 10.100.0.2/24 назначен"
    
    ip link set "$IFACE" up
    
    ip route add default via 10.100.0.1 dev "$IFACE"
    info "Шлюз 10.100.0.1 добавлен"
    
    echo "nameserver 8.8.8.8" > /etc/resolv.conf
    info "DNS-сервер 8.8.8.8 установлен"
    
    info "Статическая настройка завершена."
    show_ipv4_info
}

set_dhcp() {
    info "Настройка DHCP (сценарий #2)..."
    
    if pgrep dhclient > /dev/null; then
        pkill dhclient || true
        info "Предыдущий DHCP-клиент остановлен"
    fi
    
    ip addr flush dev "$IFACE" 2>/dev/null
    ip route flush dev "$IFACE" 2>/dev/null
    
    ip link set "$IFACE" up
    
    if command -v dhclient &> /dev/null; then
        dhclient -v "$IFACE"
        info "DHCP-клиент запущен, настройки получены."
    else
        error "Команда dhclient не найдена. Установите isc-dhcp-client."
        exit 1
    fi
    
    info "Динамическая настройка завершена."
    show_ipv4_info
}

# Главное меню
while true; do
    echo ""
    echo "========== МЕНЮ НАСТРОЙКИ СЕТИ =========="
    echo "1. Информация о сетевой карте"
    echo "2. Текущая конфигурация IPv4"
    echo "3. Настроить статический IP (сценарий #1: 10.100.0.2/24, шлюз 10.100.0.1, DNS 8.8.8.8)"
    echo "4. Настроить DHCP (сценарий #2: автоматическое получение параметров)"
    echo "5. Выход"
    echo "========================================="
    read -p "Выберите пункт [1-5]: " choice
    
    case $choice in
        1)
            show_hardware_info
            ;;
        2)
            show_ipv4_info
            ;;
        3)
            set_static
            ;;
        4)
            set_dhcp
            ;;
        5)
            info "Выход из скрипта."
            exit 0
            ;;
        *)
            error "Неверный выбор, попробуйте снова."
            ;;
    esac
done
