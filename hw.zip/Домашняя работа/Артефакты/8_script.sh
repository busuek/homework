Часть 4, пункт 7: скрипт для вывода времени и счётчиков пакетов интерфейса.

Файл ~/net_stats.sh:

#!/bin/bash
INTERFACE="bond007"
while true; do
    echo "======================"
    echo "Время: $(date '+%Y-%m-%d %H:%M:%S')"
    awk -v iface="$INTERFACE:" '$1 == iface {print "Интерфейс: " $1 "\nReceive-packets: " $2 "\nTransmit-packets: " $10}' /proc/net/dev
    sleep 2
done

Пример выполнения:

```bash
$ chmod +x ~/net_stats.sh
$ ./net_stats.sh
======================
Время: 2025-04-03 15:30:01
Интерфейс: bond007:
Receive-packets: 123456
Transmit-packets: 78901
======================
Время: 2025-04-03 15:30:03
...
